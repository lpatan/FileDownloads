package com.acme.test;

import java.io.File;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for the Traverse class.
 */
public class TraverseTest {
   
   /**
    * Tests the method that totals up the sizes of all files beginning at the root.
    */
   @Test
   public void canGetTotalSize() {
      final Traverse traverse = new Traverse();
      Assert.assertEquals(18L, traverse.totalSize(new File("data")));
   }

}
