/**
 * 
 */
package com.acme.test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * A Store holds items.
 * @author pherold
 */
public class Store {
   private final Set<Item> items = new HashSet<Item>();
   
   /**
    * Adds an item to the store.
    * @param item Item
    * @return boolean
    */
   public boolean addItem(final Item item) {
      return items.add(item);
   }
   
   /**
    * Gets if the item is in the Store.
    * @param item Item
    * @return boolean
    */
   public boolean hasItem(final Item item) {
      return items.contains(item);
   }
   
   /**
    * Gets all items in the store.
    * @return Iterator of Item
    */
   public Iterator<Item> getItems() {
      return items.iterator();
   }
   
}
