package com.acme.test;

import java.io.File;

public class Traverse {
   
   /**
    * Gets the total size of all files in the specified folder and subfolders (full depth).
    * @param folderPath File
    * @return
    */
   public long totalSize(File rootPath) {
      return 0L;
   }

}
